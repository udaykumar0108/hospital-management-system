package com.hospital.repository;

import com.hospital.config.HibernateConfig;
import com.hospital.model.Bill;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class BillRepository {

    public Bill save(Bill bill) {
        Transaction tx = null;
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.save(bill);
            tx.commit();
            return bill;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Error saving bill: " + e.getMessage(), e);
        }
    }

    public Bill update(Bill bill) {
        Transaction tx = null;
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.update(bill);
            tx.commit();
            return bill;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Error updating bill: " + e.getMessage(), e);
        }
    }

    public Bill findById(Long id) {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            return session.get(Bill.class, id);
        } catch (Exception e) {
            throw new RuntimeException("Error finding bill: " + e.getMessage(), e);
        }
    }

    public List<Bill> findByPatientId(Long patientId) {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            Query<Bill> query = session.createQuery(
                    "FROM Bill b WHERE b.patient.id = :patientId ORDER BY b.billDate DESC", Bill.class);
            query.setParameter("patientId", patientId);
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Error finding bills by patient: " + e.getMessage(), e);
        }
    }

    public List<Bill> findPending() {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            Query<Bill> query = session.createQuery(
                    "FROM Bill b WHERE b.paymentStatus = 'PENDING' ORDER BY b.billDate", Bill.class);
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Error finding pending bills: " + e.getMessage(), e);
        }
    }

    public double getTotalRevenue() {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            Query<Double> query = session.createQuery(
                    "SELECT SUM(b.totalAmount) FROM Bill b WHERE b.paymentStatus = 'PAID'", Double.class);
            Double result = query.uniqueResult();
            return result != null ? result : 0.0;
        } catch (Exception e) {
            throw new RuntimeException("Error calculating revenue: " + e.getMessage(), e);
        }
    }

    public void delete(Long id) {
        Transaction tx = null;
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            Bill bill = session.get(Bill.class, id);
            if (bill != null) session.delete(bill);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Error deleting bill: " + e.getMessage(), e);
        }
    }
}
