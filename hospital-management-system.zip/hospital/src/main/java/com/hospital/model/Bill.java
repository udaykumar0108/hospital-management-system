package com.hospital.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "bills")
public class Bill {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id", nullable = false)
    private Patient patient;

    @Column(nullable = false)
    private LocalDate billDate;

    private double consultationFee;
    private double medicineCost;
    private double roomCharges;
    private double labCharges;
    private double otherCharges;
    private double totalAmount;
    private String paymentStatus; // PAID, PENDING, PARTIAL
    private String paymentMode;   // CASH, CARD, UPI

    public Bill() {}

    public Bill(Patient patient, LocalDate billDate, double consultationFee,
                double medicineCost, double roomCharges, double labCharges,
                double otherCharges, String paymentStatus, String paymentMode) {
        this.patient = patient;
        this.billDate = billDate;
        this.consultationFee = consultationFee;
        this.medicineCost = medicineCost;
        this.roomCharges = roomCharges;
        this.labCharges = labCharges;
        this.otherCharges = otherCharges;
        this.totalAmount = consultationFee + medicineCost + roomCharges + labCharges + otherCharges;
        this.paymentStatus = paymentStatus;
        this.paymentMode = paymentMode;
    }

    public void calculateTotal() {
        this.totalAmount = consultationFee + medicineCost + roomCharges + labCharges + otherCharges;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Patient getPatient() { return patient; }
    public void setPatient(Patient patient) { this.patient = patient; }

    public LocalDate getBillDate() { return billDate; }
    public void setBillDate(LocalDate billDate) { this.billDate = billDate; }

    public double getConsultationFee() { return consultationFee; }
    public void setConsultationFee(double consultationFee) {
        this.consultationFee = consultationFee;
        calculateTotal();
    }

    public double getMedicineCost() { return medicineCost; }
    public void setMedicineCost(double medicineCost) {
        this.medicineCost = medicineCost;
        calculateTotal();
    }

    public double getRoomCharges() { return roomCharges; }
    public void setRoomCharges(double roomCharges) {
        this.roomCharges = roomCharges;
        calculateTotal();
    }

    public double getLabCharges() { return labCharges; }
    public void setLabCharges(double labCharges) {
        this.labCharges = labCharges;
        calculateTotal();
    }

    public double getOtherCharges() { return otherCharges; }
    public void setOtherCharges(double otherCharges) {
        this.otherCharges = otherCharges;
        calculateTotal();
    }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    public String getPaymentMode() { return paymentMode; }
    public void setPaymentMode(String paymentMode) { this.paymentMode = paymentMode; }
}
