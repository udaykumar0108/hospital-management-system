package com.hospital.repository;

import com.hospital.config.HibernateConfig;
import com.hospital.model.Patient;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class PatientRepository {

    // Save a new patient
    public Patient save(Patient patient) {
        Transaction tx = null;
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.save(patient);
            tx.commit();
            return patient;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Error saving patient: " + e.getMessage(), e);
        }
    }

    // Update existing patient
    public Patient update(Patient patient) {
        Transaction tx = null;
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.update(patient);
            tx.commit();
            return patient;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Error updating patient: " + e.getMessage(), e);
        }
    }

    // Find patient by ID
    public Patient findById(Long id) {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            return session.get(Patient.class, id);
        } catch (Exception e) {
            throw new RuntimeException("Error finding patient by ID: " + e.getMessage(), e);
        }
    }

    // Get all patients
    public List<Patient> findAll() {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            Query<Patient> query = session.createQuery("FROM Patient ORDER BY name", Patient.class);
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Error fetching all patients: " + e.getMessage(), e);
        }
    }

    // Find patients by status
    public List<Patient> findByStatus(String status) {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            Query<Patient> query = session.createQuery(
                    "FROM Patient WHERE status = :status ORDER BY name", Patient.class);
            query.setParameter("status", status);
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Error finding patients by status: " + e.getMessage(), e);
        }
    }

    // Search patients by name
    public List<Patient> searchByName(String name) {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            Query<Patient> query = session.createQuery(
                    "FROM Patient WHERE LOWER(name) LIKE :name ORDER BY name", Patient.class);
            query.setParameter("name", "%" + name.toLowerCase() + "%");
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Error searching patients: " + e.getMessage(), e);
        }
    }

    // Delete patient
    public void delete(Long id) {
        Transaction tx = null;
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            Patient patient = session.get(Patient.class, id);
            if (patient != null) {
                session.delete(patient);
            }
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Error deleting patient: " + e.getMessage(), e);
        }
    }

    // Count total patients
    public long count() {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            Query<Long> query = session.createQuery("SELECT COUNT(p) FROM Patient p", Long.class);
            return query.uniqueResult();
        } catch (Exception e) {
            throw new RuntimeException("Error counting patients: " + e.getMessage(), e);
        }
    }
}
