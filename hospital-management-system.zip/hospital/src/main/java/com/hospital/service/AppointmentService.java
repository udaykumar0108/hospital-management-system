package com.hospital.service;

import com.hospital.model.Appointment;
import com.hospital.model.Doctor;
import com.hospital.model.Patient;
import com.hospital.repository.AppointmentRepository;
import com.hospital.repository.PatientRepository;

import java.time.LocalDateTime;
import java.util.List;

public class AppointmentService {

    private final AppointmentRepository appointmentRepository = new AppointmentRepository();
    private final PatientRepository patientRepository = new PatientRepository();

    public Appointment scheduleAppointment(Long patientId, Doctor doctor,
                                           LocalDateTime dateTime, String reason) {
        Patient patient = patientRepository.findById(patientId);
        if (patient == null) throw new RuntimeException("Patient not found: " + patientId);

        if (dateTime.isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("Appointment date must be in the future");
        }

        Appointment appointment = new Appointment(patient, doctor, dateTime, reason, "SCHEDULED");
        return appointmentRepository.save(appointment);
    }

    public Appointment updateAppointment(Appointment appointment) {
        return appointmentRepository.update(appointment);
    }

    public void cancelAppointment(Long id) {
        Appointment appointment = appointmentRepository.findById(id);
        if (appointment == null) throw new RuntimeException("Appointment not found: " + id);
        appointment.setStatus("CANCELLED");
        appointmentRepository.update(appointment);
    }

    public void completeAppointment(Long id, String notes) {
        Appointment appointment = appointmentRepository.findById(id);
        if (appointment == null) throw new RuntimeException("Appointment not found: " + id);
        appointment.setStatus("COMPLETED");
        appointment.setNotes(notes);
        appointmentRepository.update(appointment);
    }

    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    public List<Appointment> getAppointmentsByPatient(Long patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }

    public List<Appointment> getAppointmentsByDoctor(Long doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }

    public List<Appointment> getUpcomingAppointments() {
        return appointmentRepository.findUpcoming();
    }

    public Appointment getAppointmentById(Long id) {
        Appointment appointment = appointmentRepository.findById(id);
        if (appointment == null) throw new RuntimeException("Appointment not found: " + id);
        return appointment;
    }
}
