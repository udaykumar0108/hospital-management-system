-- Hospital Management System Database Schema
-- Run this file to set up the database

CREATE DATABASE IF NOT EXISTS hospital_db;
USE hospital_db;

-- Doctors Table
CREATE TABLE IF NOT EXISTS doctors (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    specialization VARCHAR(100),
    phone       VARCHAR(15),
    email       VARCHAR(100),
    qualification VARCHAR(100),
    experience_years INT DEFAULT 0,
    availability VARCHAR(100)
);

-- Patients Table
CREATE TABLE IF NOT EXISTS patients (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    age             INT NOT NULL,
    gender          VARCHAR(10),
    phone           VARCHAR(15) NOT NULL,
    email           VARCHAR(100),
    address         TEXT,
    blood_group     VARCHAR(5),
    admission_date  DATE,
    diagnosis       TEXT,
    status          VARCHAR(20) DEFAULT 'OUTPATIENT'
);

-- Appointments Table
CREATE TABLE IF NOT EXISTS appointments (
    id                    BIGINT AUTO_INCREMENT PRIMARY KEY,
    patient_id            BIGINT NOT NULL,
    doctor_id             BIGINT NOT NULL,
    appointment_date_time DATETIME NOT NULL,
    reason                TEXT,
    status                VARCHAR(20) DEFAULT 'SCHEDULED',
    notes                 TEXT,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id)  REFERENCES doctors(id)  ON DELETE CASCADE
);

-- Bills Table
CREATE TABLE IF NOT EXISTS bills (
    id                BIGINT AUTO_INCREMENT PRIMARY KEY,
    patient_id        BIGINT NOT NULL,
    bill_date         DATE NOT NULL,
    consultation_fee  DOUBLE DEFAULT 0,
    medicine_cost     DOUBLE DEFAULT 0,
    room_charges      DOUBLE DEFAULT 0,
    lab_charges       DOUBLE DEFAULT 0,
    other_charges     DOUBLE DEFAULT 0,
    total_amount      DOUBLE DEFAULT 0,
    payment_status    VARCHAR(20) DEFAULT 'PENDING',
    payment_mode      VARCHAR(20),
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
);

-- Sample seed data
INSERT INTO doctors (name, specialization, phone, email, qualification, experience_years, availability)
VALUES
('Dr. Ramesh Kumar',   'Cardiology',      '9876543210', 'ramesh@hospital.com', 'MBBS, MD', 15, 'MON-FRI 9AM-5PM'),
('Dr. Priya Sharma',   'Neurology',       '9876543211', 'priya@hospital.com',  'MBBS, DM', 10, 'MON-SAT 10AM-4PM'),
('Dr. Arjun Mehta',    'Orthopedics',     '9876543212', 'arjun@hospital.com',  'MBBS, MS', 8,  'TUE-SAT 9AM-3PM'),
('Dr. Sneha Reddy',    'Pediatrics',      '9876543213', 'sneha@hospital.com',  'MBBS, MD', 12, 'MON-FRI 8AM-2PM'),
('Dr. Vijay Anand',    'General Surgery', '9876543214', 'vijay@hospital.com',  'MBBS, MS', 20, 'MON-FRI 9AM-5PM');

INSERT INTO patients (name, age, gender, phone, email, blood_group, admission_date, diagnosis, status)
VALUES
('Sai Kiran',    34, 'Male',   '9000000001', 'saikiran@mail.com',  'O+', CURDATE(), 'Hypertension',     'ADMITTED'),
('Lakshmi Devi', 45, 'Female', '9000000002', 'lakshmi@mail.com',   'A+', CURDATE(), 'Diabetes Type 2',  'OUTPATIENT'),
('Ravi Teja',    28, 'Male',   '9000000003', 'raviteja@mail.com',  'B+', CURDATE(), 'Fracture - Leg',   'ADMITTED'),
('Ananya Singh', 22, 'Female', '9000000004', 'ananya@mail.com',    'AB-',CURDATE(), 'Migraine',         'OUTPATIENT'),
('Suresh Babu',  60, 'Male',   '9000000005', 'suresh@mail.com',    'O-', CURDATE(), 'Cardiac Checkup',  'DISCHARGED');
