package com.hospital.controller;

import com.hospital.model.Appointment;
import com.hospital.model.Doctor;
import com.hospital.service.AppointmentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
@RequestMapping("/appointments")
public class AppointmentController {

    private final AppointmentService appointmentService = new AppointmentService();

    @GetMapping
    public String listAppointments(Model model) {
        List<Appointment> appointments = appointmentService.getAllAppointments();
        List<Appointment> upcoming = appointmentService.getUpcomingAppointments();
        model.addAttribute("appointments", appointments);
        model.addAttribute("upcomingCount", upcoming.size());
        return "appointments/list";
    }

    @GetMapping("/schedule")
    public String showScheduleForm(Model model) {
        model.addAttribute("appointment", new Appointment());
        return "appointments/schedule";
    }

    @PostMapping("/schedule")
    public String scheduleAppointment(@RequestParam Long patientId,
                                      @RequestParam Long doctorId,
                                      @RequestParam String dateTime,
                                      @RequestParam String reason,
                                      RedirectAttributes redirectAttributes) {
        try {
            LocalDateTime dt = LocalDateTime.parse(dateTime,
                    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
            Doctor doctor = new Doctor();
            doctor.setId(doctorId);
            appointmentService.scheduleAppointment(patientId, doctor, dt, reason);
            redirectAttributes.addFlashAttribute("success", "Appointment scheduled!");
            return "redirect:/appointments";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error: " + e.getMessage());
            return "redirect:/appointments/schedule";
        }
    }

    @PostMapping("/{id}/cancel")
    public String cancelAppointment(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            appointmentService.cancelAppointment(id);
            redirectAttributes.addFlashAttribute("success", "Appointment cancelled.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error: " + e.getMessage());
        }
        return "redirect:/appointments";
    }

    @PostMapping("/{id}/complete")
    public String completeAppointment(@PathVariable Long id,
                                      @RequestParam String notes,
                                      RedirectAttributes redirectAttributes) {
        try {
            appointmentService.completeAppointment(id, notes);
            redirectAttributes.addFlashAttribute("success", "Appointment marked as completed.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error: " + e.getMessage());
        }
        return "redirect:/appointments";
    }

    @GetMapping("/patient/{patientId}")
    public String getPatientAppointments(@PathVariable Long patientId, Model model) {
        List<Appointment> appointments = appointmentService.getAppointmentsByPatient(patientId);
        model.addAttribute("appointments", appointments);
        model.addAttribute("patientId", patientId);
        return "appointments/list";
    }
}
