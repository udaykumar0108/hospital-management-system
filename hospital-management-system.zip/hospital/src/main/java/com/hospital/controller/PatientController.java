package com.hospital.controller;

import com.hospital.model.Patient;
import com.hospital.service.PatientService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/patients")
public class PatientController {

    private final PatientService patientService = new PatientService();

    // List all patients
    @GetMapping
    public String listPatients(@RequestParam(required = false) String search, Model model) {
        List<Patient> patients;
        if (search != null && !search.trim().isEmpty()) {
            patients = patientService.searchPatients(search);
            model.addAttribute("search", search);
        } else {
            patients = patientService.getAllPatients();
        }
        model.addAttribute("patients", patients);
        model.addAttribute("totalCount", patientService.getTotalPatientCount());
        return "patients/list";
    }

    // Show registration form
    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("patient", new Patient());
        return "patients/register";
    }

    // Process registration
    @PostMapping("/register")
    public String registerPatient(@ModelAttribute Patient patient,
                                  RedirectAttributes redirectAttributes) {
        try {
            patient.setAdmissionDate(LocalDate.now());
            patientService.registerPatient(patient);
            redirectAttributes.addFlashAttribute("success", "Patient registered successfully!");
            return "redirect:/patients";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error: " + e.getMessage());
            return "redirect:/patients/register";
        }
    }

    // View patient details
    @GetMapping("/{id}")
    public String viewPatient(@PathVariable Long id, Model model) {
        try {
            Patient patient = patientService.getPatientById(id);
            model.addAttribute("patient", patient);
            return "patients/view";
        } catch (Exception e) {
            return "redirect:/patients";
        }
    }

    // Show edit form
    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable Long id, Model model) {
        try {
            Patient patient = patientService.getPatientById(id);
            model.addAttribute("patient", patient);
            return "patients/edit";
        } catch (Exception e) {
            return "redirect:/patients";
        }
    }

    // Process edit
    @PostMapping("/{id}/edit")
    public String updatePatient(@PathVariable Long id, @ModelAttribute Patient patient,
                                RedirectAttributes redirectAttributes) {
        try {
            patient.setId(id);
            patientService.updatePatient(patient);
            redirectAttributes.addFlashAttribute("success", "Patient updated successfully!");
            return "redirect:/patients/" + id;
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error: " + e.getMessage());
            return "redirect:/patients/" + id + "/edit";
        }
    }

    // Discharge patient
    @PostMapping("/{id}/discharge")
    public String dischargePatient(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            patientService.dischargePatient(id);
            redirectAttributes.addFlashAttribute("success", "Patient discharged successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error: " + e.getMessage());
        }
        return "redirect:/patients/" + id;
    }

    // Delete patient
    @PostMapping("/{id}/delete")
    public String deletePatient(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            patientService.deletePatient(id);
            redirectAttributes.addFlashAttribute("success", "Patient deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error: " + e.getMessage());
        }
        return "redirect:/patients";
    }
}
