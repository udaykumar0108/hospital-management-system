package com.hospital.controller;

import com.hospital.service.AppointmentService;
import com.hospital.service.BillingService;
import com.hospital.service.PatientService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class DashboardController {

    private final PatientService patientService = new PatientService();
    private final AppointmentService appointmentService = new AppointmentService();
    private final BillingService billingService = new BillingService();

    @GetMapping
    public String dashboard(Model model) {
        model.addAttribute("totalPatients", patientService.getTotalPatientCount());
        model.addAttribute("admittedPatients", patientService.getAdmittedPatients().size());
        model.addAttribute("upcomingAppointments", appointmentService.getUpcomingAppointments().size());
        model.addAttribute("pendingBills", billingService.getPendingBills().size());
        model.addAttribute("totalRevenue", billingService.getTotalRevenue());
        model.addAttribute("recentPatients", patientService.getAllPatients()
                .stream().limit(5).toList());
        return "dashboard";
    }
}
