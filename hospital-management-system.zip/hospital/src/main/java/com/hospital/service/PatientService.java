package com.hospital.service;

import com.hospital.model.Patient;
import com.hospital.repository.PatientRepository;

import java.util.List;

public class PatientService {

    private final PatientRepository patientRepository = new PatientRepository();

    public Patient registerPatient(Patient patient) {
        validatePatient(patient);
        return patientRepository.save(patient);
    }

    public Patient updatePatient(Patient patient) {
        if (patient.getId() == null) {
            throw new IllegalArgumentException("Patient ID is required for update");
        }
        validatePatient(patient);
        return patientRepository.update(patient);
    }

    public Patient getPatientById(Long id) {
        Patient patient = patientRepository.findById(id);
        if (patient == null) {
            throw new RuntimeException("Patient not found with ID: " + id);
        }
        return patient;
    }

    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    public List<Patient> getAdmittedPatients() {
        return patientRepository.findByStatus("ADMITTED");
    }

    public List<Patient> getOutpatients() {
        return patientRepository.findByStatus("OUTPATIENT");
    }

    public List<Patient> searchPatients(String name) {
        if (name == null || name.trim().isEmpty()) {
            return getAllPatients();
        }
        return patientRepository.searchByName(name.trim());
    }

    public void dischargePatient(Long id) {
        Patient patient = getPatientById(id);
        patient.setStatus("DISCHARGED");
        patientRepository.update(patient);
    }

    public void deletePatient(Long id) {
        patientRepository.delete(id);
    }

    public long getTotalPatientCount() {
        return patientRepository.count();
    }

    private void validatePatient(Patient patient) {
        if (patient.getName() == null || patient.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Patient name is required");
        }
        if (patient.getAge() <= 0 || patient.getAge() > 150) {
            throw new IllegalArgumentException("Invalid patient age");
        }
        if (patient.getPhone() == null || patient.getPhone().trim().isEmpty()) {
            throw new IllegalArgumentException("Patient phone is required");
        }
    }
}
