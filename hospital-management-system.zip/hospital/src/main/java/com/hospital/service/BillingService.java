package com.hospital.service;

import com.hospital.model.Bill;
import com.hospital.model.Patient;
import com.hospital.repository.BillRepository;
import com.hospital.repository.PatientRepository;

import java.time.LocalDate;
import java.util.List;

public class BillingService {

    private final BillRepository billRepository = new BillRepository();
    private final PatientRepository patientRepository = new PatientRepository();

    public Bill generateBill(Long patientId, double consultationFee, double medicineCost,
                             double roomCharges, double labCharges, double otherCharges,
                             String paymentMode) {
        Patient patient = patientRepository.findById(patientId);
        if (patient == null) throw new RuntimeException("Patient not found: " + patientId);

        Bill bill = new Bill(patient, LocalDate.now(), consultationFee, medicineCost,
                roomCharges, labCharges, otherCharges, "PENDING", paymentMode);
        return billRepository.save(bill);
    }

    public Bill markAsPaid(Long billId) {
        Bill bill = billRepository.findById(billId);
        if (bill == null) throw new RuntimeException("Bill not found: " + billId);
        bill.setPaymentStatus("PAID");
        return billRepository.update(bill);
    }

    public List<Bill> getBillsByPatient(Long patientId) {
        return billRepository.findByPatientId(patientId);
    }

    public List<Bill> getPendingBills() {
        return billRepository.findPending();
    }

    public Bill getBillById(Long id) {
        Bill bill = billRepository.findById(id);
        if (bill == null) throw new RuntimeException("Bill not found: " + id);
        return bill;
    }

    public double getTotalRevenue() {
        return billRepository.getTotalRevenue();
    }

    public Bill updateBill(Bill bill) {
        bill.calculateTotal();
        return billRepository.update(bill);
    }
}
