package com.hospital.repository;

import com.hospital.config.HibernateConfig;
import com.hospital.model.Appointment;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.time.LocalDateTime;
import java.util.List;

public class AppointmentRepository {

    public Appointment save(Appointment appointment) {
        Transaction tx = null;
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.save(appointment);
            tx.commit();
            return appointment;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Error saving appointment: " + e.getMessage(), e);
        }
    }

    public Appointment update(Appointment appointment) {
        Transaction tx = null;
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.update(appointment);
            tx.commit();
            return appointment;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Error updating appointment: " + e.getMessage(), e);
        }
    }

    public Appointment findById(Long id) {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            return session.get(Appointment.class, id);
        } catch (Exception e) {
            throw new RuntimeException("Error finding appointment: " + e.getMessage(), e);
        }
    }

    public List<Appointment> findAll() {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            Query<Appointment> query = session.createQuery(
                    "FROM Appointment a JOIN FETCH a.patient JOIN FETCH a.doctor ORDER BY a.appointmentDateTime",
                    Appointment.class);
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Error fetching appointments: " + e.getMessage(), e);
        }
    }

    public List<Appointment> findByPatientId(Long patientId) {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            Query<Appointment> query = session.createQuery(
                    "FROM Appointment a WHERE a.patient.id = :patientId ORDER BY a.appointmentDateTime",
                    Appointment.class);
            query.setParameter("patientId", patientId);
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Error finding appointments by patient: " + e.getMessage(), e);
        }
    }

    public List<Appointment> findByDoctorId(Long doctorId) {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            Query<Appointment> query = session.createQuery(
                    "FROM Appointment a WHERE a.doctor.id = :doctorId ORDER BY a.appointmentDateTime",
                    Appointment.class);
            query.setParameter("doctorId", doctorId);
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Error finding appointments by doctor: " + e.getMessage(), e);
        }
    }

    public List<Appointment> findUpcoming() {
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            Query<Appointment> query = session.createQuery(
                    "FROM Appointment a WHERE a.appointmentDateTime >= :now AND a.status = 'SCHEDULED' ORDER BY a.appointmentDateTime",
                    Appointment.class);
            query.setParameter("now", LocalDateTime.now());
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Error finding upcoming appointments: " + e.getMessage(), e);
        }
    }

    public void delete(Long id) {
        Transaction tx = null;
        try (Session session = HibernateConfig.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            Appointment appointment = session.get(Appointment.class, id);
            if (appointment != null) session.delete(appointment);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Error deleting appointment: " + e.getMessage(), e);
        }
    }
}
