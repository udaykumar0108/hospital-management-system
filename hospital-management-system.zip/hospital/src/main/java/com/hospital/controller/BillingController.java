package com.hospital.controller;

import com.hospital.model.Bill;
import com.hospital.service.BillingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/billing")
public class BillingController {

    private final BillingService billingService = new BillingService();

    @GetMapping
    public String listBills(Model model) {
        List<Bill> pendingBills = billingService.getPendingBills();
        model.addAttribute("pendingBills", pendingBills);
        model.addAttribute("totalRevenue", billingService.getTotalRevenue());
        return "billing/list";
    }

    @GetMapping("/generate/{patientId}")
    public String showGenerateBillForm(@PathVariable Long patientId, Model model) {
        model.addAttribute("patientId", patientId);
        return "billing/generate";
    }

    @PostMapping("/generate")
    public String generateBill(@RequestParam Long patientId,
                               @RequestParam double consultationFee,
                               @RequestParam double medicineCost,
                               @RequestParam double roomCharges,
                               @RequestParam double labCharges,
                               @RequestParam double otherCharges,
                               @RequestParam String paymentMode,
                               RedirectAttributes redirectAttributes) {
        try {
            Bill bill = billingService.generateBill(patientId, consultationFee, medicineCost,
                    roomCharges, labCharges, otherCharges, paymentMode);
            redirectAttributes.addFlashAttribute("success",
                    "Bill generated. Total: ₹" + bill.getTotalAmount());
            return "redirect:/billing/" + bill.getId();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error: " + e.getMessage());
            return "redirect:/billing/generate/" + patientId;
        }
    }

    @GetMapping("/{id}")
    public String viewBill(@PathVariable Long id, Model model) {
        try {
            Bill bill = billingService.getBillById(id);
            model.addAttribute("bill", bill);
            return "billing/view";
        } catch (Exception e) {
            return "redirect:/billing";
        }
    }

    @PostMapping("/{id}/pay")
    public String markAsPaid(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            billingService.markAsPaid(id);
            redirectAttributes.addFlashAttribute("success", "Payment recorded successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error: " + e.getMessage());
        }
        return "redirect:/billing/" + id;
    }

    @GetMapping("/patient/{patientId}")
    public String getPatientBills(@PathVariable Long patientId, Model model) {
        List<Bill> bills = billingService.getBillsByPatient(patientId);
        model.addAttribute("bills", bills);
        return "billing/patient-bills";
    }
}
